#!/usr/bin/env python3
"""Business-free AKS repros using only native Kubernetes objects and public images."""
import argparse
import concurrent.futures
import datetime as dt
import gzip
import json
import math
import re
import selectors
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

IMAGE = "mcr.microsoft.com/oss/v2/kubernetes/pause:3.6"
DEBUG_IMAGE = "mcr.microsoft.com/aks/fundamental/base-ubuntu:v0.0.11"
KATA_V2_CONFIG = "/usr/share/defaults/kata-containers/configuration-clh-azure-runtime-rs-v2.toml"


class ApiError(RuntimeError):
    def __init__(self, status, message):
        super().__init__(f"Kubernetes HTTP {status}: {message}")
        self.status = status


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


class Kubernetes:
    def __init__(self, context, output):
        self.context, self.output = context, output
        self.lock = threading.Lock()
        self.log = (output / "proxy-stderr.log").open("w")
        self.process = subprocess.Popen(
            ["kubectl", "--context", context, "proxy", "--address=127.0.0.1", "--port=0"],
            stdout=subprocess.PIPE, stderr=self.log, text=True)
        selector = selectors.DefaultSelector()
        try:
            selector.register(self.process.stdout, selectors.EVENT_READ)
            if not selector.select(timeout=30):
                raise TimeoutError("kubectl proxy did not announce readiness within 30 seconds")
            announcement = self.process.stdout.readline()
            match = re.search(r"127\.0\.0\.1:(\d+)", announcement)
            if not match:
                raise RuntimeError(f"kubectl proxy failed: {announcement}; see proxy-stderr.log")
            self.url = f"http://127.0.0.1:{match[1]}"
            self.request("GET", "/version")
        except (TimeoutError, RuntimeError, OSError):
            self.close()
            raise
        finally:
            selector.close()

    def close(self):
        self.process.terminate()
        try:
            self.process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=15)
        self.process.stdout.close()
        self.log.close()

    def open(self, method, path, body=None, timeout=120):
        payload = None if body is None else json.dumps(body).encode()
        request = urllib.request.Request(
            self.url + path, data=payload, method=method,
            headers={"Content-Type": "application/json"})
        started = utc()
        try:
            response = urllib.request.urlopen(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            message = error.read().decode()
            self.record(method, path, started, error.code, error.headers.get("Audit-Id"))
            raise ApiError(error.code, message) from error
        self.record(method, path, started, response.status, response.headers.get("Audit-Id"))
        return response

    def record(self, method, path, started, status, audit_id):
        with self.lock:
            with (self.output / "client-api.jsonl").open("a") as stream:
                stream.write(json.dumps({"started": started, "finished": utc(), "method": method,
                                         "path": path, "status": status, "audit_id": audit_id}) + "\n")

    def request(self, method, path, body=None):
        with self.open(method, path, body) as response:
            return json.load(response)

    def get(self, path):
        try:
            return self.request("GET", path)
        except ApiError as error:
            if error.status != 404:
                raise
            return None

    def wait(self, collection, name, predicate, timeout=120):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            current = self.get(f"{collection}/{name}")
            if predicate(current):
                return current
            if current is None:
                raise RuntimeError(f"Object disappeared while waiting: {collection}/{name}")
            remaining = max(1, math.ceil(deadline - time.monotonic()))
            query = urllib.parse.urlencode({
                "watch": "true", "fieldSelector": f"metadata.name={name}",
                "resourceVersion": current["metadata"]["resourceVersion"],
                "timeoutSeconds": remaining})
            with self.open("GET", collection + "?" + query, timeout=remaining + 10) as response:
                for line in response:
                    if not line.strip():
                        continue
                    event = json.loads(line)
                    if event["type"] == "ERROR":
                        raise RuntimeError(f"Kubernetes watch error: {event['object']}")
                    current = None if event["type"] == "DELETED" else event["object"]
                    if predicate(current):
                        return current
        raise TimeoutError(f"Condition not reached in {timeout}s: {collection}/{name}")

    def delete(self, collection, obj):
        name, uid = obj["metadata"]["name"], obj["metadata"]["uid"]
        self.request("DELETE", f"{collection}/{name}", {
            "apiVersion": "v1", "kind": "DeleteOptions", "preconditions": {"uid": uid}})
        self.wait(collection, name, lambda current: current is None)


def ready(pod):
    return pod is not None and any(
        condition["type"] == "Ready" and condition["status"] == "True"
        for condition in pod.get("status", {}).get("conditions", []))


def pod_manifest(namespace, name, pool, runtime_class, memory, claim=None, block=False):
    spec = {
        "restartPolicy": "Never", "automountServiceAccountToken": False,
        "terminationGracePeriodSeconds": 0,
        "nodeSelector": {"kubernetes.azure.com/agentpool": pool},
        "containers": [{"name": "pause", "image": IMAGE, "imagePullPolicy": "IfNotPresent",
                        "resources": {"requests": {"cpu": "1" if runtime_class else "10m", "memory": memory},
                                      "limits": {"cpu": "1", "memory": memory}}}],
    }
    if runtime_class:
        spec["runtimeClassName"] = runtime_class
    if claim:
        spec["volumes"] = [{"name": "scratch", "persistentVolumeClaim": {"claimName": claim}}]
        if block:
            spec["containers"][0]["volumeDevices"] = [
                {"name": "scratch", "devicePath": "/dev/repro"}]
        else:
            spec["containers"][0]["volumeMounts"] = [
                {"name": "scratch", "mountPath": "/scratch", "readOnly": True}]
    return {"apiVersion": "v1", "kind": "Pod",
            "metadata": {"name": name, "namespace": namespace,
                         "labels": {"aks-native-repro": namespace}}, "spec": spec}


def delete_volume(api, args, namespace, claim, volume):
    if claim is not None:
        api.delete(f"/api/v1/namespaces/{namespace}/persistentvolumeclaims", claim)
    if volume is not None:
        if args.block_storage_class:
            api.wait("/api/v1/persistentvolumes", volume["metadata"]["name"],
                     lambda obj: obj is None, timeout=300)
        else:
            api.delete("/api/v1/persistentvolumes", volume)


def prepare_volume(api, args, namespace, number):
    prefix = f"/api/v1/namespaces/{namespace}"
    name = f"p-{number:04d}"
    claim = volume = None
    block = bool(args.block_storage_class)
    try:
        claim = api.request("POST", prefix + "/persistentvolumeclaims", {
            "apiVersion": "v1", "kind": "PersistentVolumeClaim",
            "metadata": {"name": name, "labels": {"aks-native-repro": namespace}},
            "spec": {"accessModes": ["ReadWriteOncePod" if block else "ReadWriteOnce"],
                     "storageClassName": args.block_storage_class,
                     "volumeMode": "Block" if block else "Filesystem",
                     "resources": {"requests": {"storage": "1Gi" if block else "1Mi"}}}})
        if not block:
            volume = api.request("POST", "/api/v1/persistentvolumes", {
                "apiVersion": "v1", "kind": "PersistentVolume",
                "metadata": {"name": f"{namespace}-{name}", "labels": {"aks-native-repro": namespace}},
                "spec": {"capacity": {"storage": "1Mi"}, "accessModes": ["ReadWriteOnce"],
                         "storageClassName": "", "persistentVolumeReclaimPolicy": "Retain",
                         "claimRef": {"namespace": namespace, "name": name,
                                      "uid": claim["metadata"]["uid"]},
                         "hostPath": {"path": (
                             f"/var/tmp/aks-pv-auth-repro/{namespace}/{name}" if args.burst
                             else "/var/tmp/aks-pv-auth-repro"), "type": "DirectoryOrCreate"}}})
        claim = api.wait(prefix + "/persistentvolumeclaims", name,
                         lambda obj: obj is not None and obj.get("status", {}).get("phase") == "Bound",
                         timeout=300 if block else 120)
        if block:
            volume = api.request("GET", "/api/v1/persistentvolumes/" + claim["spec"]["volumeName"])
        reference = volume["spec"]["claimRef"]
        if (claim["spec"]["volumeName"] != volume["metadata"]["name"]
                or reference["uid"] != claim["metadata"]["uid"]
                or reference["namespace"] != namespace or reference["name"] != name):
            raise RuntimeError("PVC/PV binding identity mismatch")
        save(args.output / f"{number:04d}-binding.json", {"pvc": claim, "pv_created": volume})
        return claim, volume
    except (RuntimeError, OSError):
        save(args.output / f"{number:04d}-preparation-failure.json", {
            "pvc": claim, "pv_created": volume, "failed_at": utc()})
        delete_volume(api, args, namespace, claim, volume)
        raise


def observe_pod(api, args, namespace, number, phase, pod, created_at, started):
    observed = api.wait(f"/api/v1/namespaces/{namespace}/pods", pod["metadata"]["name"], ready)
    result = {"number": number, "phase": phase, "pod": pod["metadata"]["name"],
              "uid": pod["metadata"]["uid"], "node": observed["spec"]["nodeName"],
              "created_request_at": created_at, "observed_ready_at": utc(),
              "trial_ms": (time.monotonic() - started) * 1000,
              "pod_created_to_ready_ms": (
                  dt.datetime.now(dt.timezone.utc) -
                  dt.datetime.fromisoformat(created_at)).total_seconds() * 1000}
    save(args.output / f"{number:04d}-ready.json", observed)
    save(args.output / f"{number:04d}-result.json", result)
    return result


def run_trial(api, args, namespace, number, phase):
    prefix = f"/api/v1/namespaces/{namespace}"
    name = f"p-{number:04d}"
    claim = volume = None
    block = bool(args.block_storage_class)
    started = time.monotonic()
    try:
        if args.scenario == "volume":
            claim, volume = prepare_volume(api, args, namespace, number)
        manifest = pod_manifest(namespace, name, args.pool, args.runtime_class,
                                "2Gi" if args.scenario == "kata" else "512Mi",
                                name if claim else None, block)
        save(args.output / f"{number:04d}-manifest.json", manifest)
        created_at = utc()
        pod = api.request("POST", prefix + "/pods", manifest)
        result = observe_pod(api, args, namespace, number, phase, pod, created_at, started)
        api.delete(prefix + "/pods", pod)
        return result
    finally:
        if claim is not None:
            pod = api.get(prefix + "/pods/" + name)
            if pod is not None:
                save(args.output / f"{number:04d}-final-pod.json", pod)
                api.delete(prefix + "/pods", pod)
        delete_volume(api, args, namespace, claim, volume)


def run_burst(api, args, namespace):
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        list(executor.map(lambda index: prepare_volume(api, args, namespace, index), range(args.count)))
    prepared_at = utc()
    gate = threading.Barrier(args.count + 1, timeout=60, action=lambda: save(
        args.output / "burst-release.json", {
            "all_claims_bound_at": prepared_at, "barrier_release_at": utc(),
            "participants": args.count, "workload_deletion_during_observation": False}))
    manifests = [
        pod_manifest(namespace, f"p-{index:04d}", args.pool, args.runtime_class,
                     "512Mi" if args.runtime_class else "64Mi", f"p-{index:04d}",
                     bool(args.block_storage_class))
        for index in range(args.count)]
    for index, manifest in enumerate(manifests):
        save(args.output / f"{index:04d}-manifest.json", manifest)

    def publish(index):
        gate.wait()
        created_at, started = utc(), time.monotonic()
        pod = api.request("POST", f"/api/v1/namespaces/{namespace}/pods", manifests[index])
        save(args.output / f"{index:04d}-created.json", pod)
        return index, pod, created_at, started

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.count) as executor:
        futures = [executor.submit(publish, index) for index in range(args.count)]
        gate.wait()
        published = [future.result() for future in futures]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        results = list(executor.map(
            lambda item: observe_pod(api, args, namespace, item[0], "burst", item[1], item[2], item[3]),
            published))
    timestamps = [dt.datetime.fromisoformat(item[2]) for item in published]
    save(args.output / "burst-observation.json", {
        "all_ready_at": utc(), "live_workload_pods": len(results),
        "client_submit_spread_ms": (max(timestamps) - min(timestamps)).total_seconds() * 1000,
        "workload_deletion_during_observation": False})
    return results


def cleanup_burst(api, args, namespace):
    prefix = f"/api/v1/namespaces/{namespace}"
    save(args.output / "workload-cleanup-start.json", {"started": utc()})
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        for resource in ("pods", "persistentvolumeclaims"):
            objects = api.request("GET", prefix + "/" + resource)["items"]
            list(executor.map(lambda obj: api.delete(prefix + "/" + resource, obj), objects))
        volumes = api.request("GET", "/api/v1/persistentvolumes")["items"]
        owned = [pv for pv in volumes if (pv["spec"].get("claimRef") or {}).get("namespace") == namespace]
        if args.block_storage_class:
            list(executor.map(
                lambda pv: api.wait("/api/v1/persistentvolumes", pv["metadata"]["name"],
                                    lambda obj: obj is None, timeout=300), owned))
        else:
            list(executor.map(lambda pv: api.delete("/api/v1/persistentvolumes", pv), owned))


def run_node_command(api, namespace, name, node_name, script):
    prefix = f"/api/v1/namespaces/{namespace}"
    pod = api.request("POST", prefix + "/pods", {
        "apiVersion": "v1", "kind": "Pod", "metadata": {"name": name},
        "spec": {"nodeName": node_name, "hostPID": True, "restartPolicy": "Never",
                 "activeDeadlineSeconds": 180, "automountServiceAccountToken": False,
                 "containers": [{"name": "host", "image": DEBUG_IMAGE,
                                 "securityContext": {"privileged": True},
                                 "command": ["nsenter", "-t", "1", "-m", "-u", "-i", "-n", "-p",
                                             "--", "/bin/bash", "-euo", "pipefail", "-c", script]}]}})
    try:
        state = api.wait(prefix + "/pods", name,
                         lambda obj: obj is not None and obj.get("status", {}).get("phase") in ("Succeeded", "Failed"),
                         timeout=180)
        with api.open("GET", prefix + f"/pods/{name}/log") as response:
            output = response.read().decode()
        if state["status"]["phase"] != "Succeeded":
            raise RuntimeError(f"Host command {name} failed on {node_name}: {output}")
        return output
    finally:
        api.delete(prefix + "/pods", pod)


def configure_kata_template(api, args, namespace):
    if args.kata_template == "auto":
        return []
    nodes = [
        node["metadata"]["name"] for node in api.request("GET", "/api/v1/nodes")["items"]
        if node["metadata"]["labels"].get("kubernetes.azure.com/agentpool") == args.pool
    ]
    if not nodes:
        raise RuntimeError(f"No nodes found in pool {args.pool}")
    records = []
    for index, node_name in enumerate(nodes):
        if args.kata_template == "off":
            out = run_node_command(api, namespace, f"kata-tpl-off-{index}", node_name, (
                f"/usr/local/bin/kata-ctl --config {KATA_V2_CONFIG} factory destroy >/dev/null 2>&1 || true\n"
                f"cp {KATA_V2_CONFIG} {KATA_V2_CONFIG}.repro.bak\n"
                f"sed -i 's/^enable_template = true$/enable_template = false/' {KATA_V2_CONFIG}\n"
                f"grep -n '^enable_template = false$' {KATA_V2_CONFIG}"
            ))
            records.append({"node": node_name, "mode": "off", "detail": out.strip()})
        elif args.kata_template == "init":
            out = run_node_command(api, namespace, f"kata-tpl-init-{index}", node_name, (
                f"sed -i 's/^enable_template = false$/enable_template = true/' {KATA_V2_CONFIG}\n"
                f"/usr/local/bin/kata-ctl --config {KATA_V2_CONFIG} factory destroy >/dev/null 2>&1 || true\n"
                "t0=$(date +%s%N)\n"
                "set +e\n"
                f"/usr/local/bin/kata-ctl --config {KATA_V2_CONFIG} factory init >/tmp/kata-factory-init-1.log 2>&1\n"
                "rc1=$?\n"
                "set -e\n"
                "t1=$(date +%s%N)\n"
                'printf "ATTEMPT1_RC=%s ATTEMPT1_NS=%s\\n" "$rc1" "$((t1 - t0))"\n'
                "if [ \"$rc1\" -ne 0 ]; then\n"
                '  echo "=== ATTEMPT1_LOG ==="\n'
                "  tail -n 40 /tmp/kata-factory-init-1.log || true\n"
                "  t2=$(date +%s%N)\n"
                f"  /usr/local/bin/kata-ctl --config {KATA_V2_CONFIG} factory init >/tmp/kata-factory-init-2.log 2>&1 || {{ cat /tmp/kata-factory-init-2.log; exit 1; }}\n"
                "  t3=$(date +%s%N)\n"
                '  printf "ATTEMPT2_RC=0 ATTEMPT2_NS=%s\\n" "$((t3 - t2))"\n'
                "fi\n"
                "test -f /run/vc/vm/template/memory && test -f /run/vc/vm/template/state.json\n"
                "ls -lh /run/vc/vm/template"
            ))
            m1 = re.search(r"ATTEMPT1_RC=(\d+) ATTEMPT1_NS=(\d+)", out)
            if not m1:
                raise RuntimeError(f"Missing factory init timing on {node_name}: {out}")
            m2 = re.search(r"ATTEMPT2_RC=0 ATTEMPT2_NS=(\d+)", out)
            records.append({
                "node": node_name, "mode": "init",
                "attempt1_rc": int(m1[1]),
                "attempt1_ms": int(m1[2]) / 1_000_000,
                "attempt2_ms": int(m2[1]) / 1_000_000 if m2 else None,
                "factory_init_ms": (int(m2[1]) if m2 else int(m1[2])) / 1_000_000,
                "detail": out.strip(),
            })
    save(args.output / "kata-template-setup.json", records)
    return nodes


def cleanup_kata_template(api, args, namespace, nodes):
    for index, node_name in enumerate(nodes):
        if args.kata_template == "off":
            run_node_command(api, namespace, f"kata-tpl-restore-{index}", node_name, (
                f"if [ -f {KATA_V2_CONFIG}.repro.bak ]; then mv {KATA_V2_CONFIG}.repro.bak {KATA_V2_CONFIG}; fi"
            ))
        elif args.kata_template == "init":
            run_node_command(api, namespace, f"kata-tpl-destroy-{index}", node_name, (
                f"/usr/local/bin/kata-ctl --config {KATA_V2_CONFIG} factory destroy >/dev/null 2>&1 || true"
            ))


def collect(api, args, namespace, since):
    prefix = f"/api/v1/namespaces/{namespace}"
    save(args.output / "events.json", api.request("GET", prefix + "/events"))
    nodes = api.request("GET", "/api/v1/nodes")
    save(args.output / "nodes.json", nodes)
    save(args.output / "runtimeclasses.json", api.request("GET", "/apis/node.k8s.io/v1/runtimeclasses"))
    for index, node in enumerate(nodes["items"]):
        if node["metadata"]["labels"].get("kubernetes.azure.com/agentpool") != args.pool:
            continue
        name = node["metadata"]["name"]
        diagnostic = f"journal-{index}"
        since_utc = dt.datetime.fromisoformat(since).astimezone(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        diagnostic_pod = api.request("POST", prefix + "/pods", {
            "apiVersion": "v1", "kind": "Pod", "metadata": {"name": diagnostic},
            "spec": {"nodeName": name, "hostPID": True, "hostNetwork": True,
                     "restartPolicy": "Never", "activeDeadlineSeconds": 300,
                     "automountServiceAccountToken": False,
                     "volumes": [{"name": "host", "hostPath": {"path": "/", "type": "Directory"}}],
                     "containers": [{"name": "journal", "image": DEBUG_IMAGE,
                                     "securityContext": {"privileged": True},
                                     "volumeMounts": [{"name": "host", "mountPath": "/host", "readOnly": True}],
                                     "command": ["/bin/sh", "-c",
                                                 "chroot /host /bin/bash -o pipefail -c "
                                                 "'journalctl --since=\"$1\" --no-pager --output=json | gzip -c' "
                                                 'journal-collector "$1" > /tmp/host-journal.gz'
                                                 " && touch /tmp/journal-ready && sleep 300",
                                                 "journal-collector", since_utc],
                                     "readinessProbe": {
                                         "exec": {"command": ["test", "-f", "/tmp/journal-ready"]},
                                         "periodSeconds": 1, "failureThreshold": 180}}]}})
        try:
            state = api.wait(prefix + "/pods", diagnostic,
                             lambda pod: ready(pod) or (
                                 pod is not None and pod.get("status", {}).get("phase") == "Failed"),
                             timeout=180)
            if not ready(state):
                with api.open("GET", prefix + f"/pods/{diagnostic}/log") as response:
                    (args.output / f"{name}.collector-error.log").write_bytes(response.read())
                raise RuntimeError(f"Node journal collector failed on {name}; see collector-error.log")
            # Exec copies the complete file without kubelet stdout-log rotation or attach races.
            compressed = args.output / f"{name}.journal.gz"
            with compressed.open("wb") as stream:
                subprocess.run(
                    ["kubectl", "--context", args.context, "exec", "-n", namespace,
                     diagnostic, "--", "cat", "/tmp/host-journal.gz"],
                    check=True, timeout=180, stdout=stream)
            (args.output / f"{name}.journal.jsonl").write_bytes(gzip.decompress(compressed.read_bytes()))
        finally:
            api.delete(prefix + "/pods", diagnostic_pod)


def journal_summary(args, namespace):
    entries = []
    for path in sorted(args.output.glob("*.journal.jsonl")):
        count = 0
        for number, line in enumerate(path.read_text().splitlines(), 1):
            if not line.startswith("{"):
                continue
            row = json.loads(line)
            if "__REALTIME_TIMESTAMP" not in row:
                continue
            count += 1
            message = row.get("MESSAGE", "")
            if isinstance(message, str):
                entries.append({"time_ms": int(row["__REALTIME_TIMESTAMP"]) / 1000,
                                "pid": str(row.get("_PID", "")),
                                "comm": str(row.get("_COMM", "")),
                                "message": message.replace('\\"', '"'),
                                "source": f"{path.name}:{number}"})
        if not count:
            raise RuntimeError(f"No native journal records captured: {path}")
    if not entries:
        raise RuntimeError("No matching node journals were captured")
    results = json.loads((args.output / "results.json").read_text())
    summaries = []
    for result in results:
        name = result["pod"]
        cri = [entry for entry in entries if "RunPodSandbox for" in entry["message"]
               and result["uid"] in entry["message"]]
        start = next((entry for entry in cri if "returns sandbox id" not in entry["message"]), None)
        end = next((entry for entry in cri if "returns sandbox id" in entry["message"]), None)
        if start is None or end is None:
            raise RuntimeError(f"Missing native RunPodSandbox start/end for {namespace}/{name}")
        sandbox_id = re.search(r'returns sandbox id "([^"]+)"', end["message"])[1]
        markers = {}
        for entry in entries:
            if f"sandbox={sandbox_id}" not in entry["message"]:
                continue
            for marker in ("Starting VM", "VM started", "Agent started in the sandbox"):
                if f'msg="{marker}"' in entry["message"]:
                    markers.setdefault(marker, entry)
        summary = {**result, "sandbox_id": sandbox_id,
                   "sandbox_start_time_ms": start["time_ms"],
                   "sandbox_ms": end["time_ms"] - start["time_ms"],
                   "sandbox_source": [start["source"], end["source"]]}
        if args.scenario == "kata":
            if len(markers) == 3:
                summary["shim_flavor"] = "kata-go"
                summary["restored_from_template"] = False
                summary["hypervisor_ms"] = markers["VM started"]["time_ms"] - markers["Starting VM"]["time_ms"]
                summary["guest_agent_ms"] = markers["Agent started in the sandbox"]["time_ms"] - markers["VM started"]["time_ms"]
                summary["markers"] = markers
            else:
                bind = next((entry for entry in entries
                             if f"/run/kata/{sandbox_id}/shim-monitor.sock" in entry["message"]
                             and entry["comm"] == "containerd-shim"), None)
                if bind is None:
                    raise RuntimeError(f"Missing Kata host milestones for {namespace}/{name}")
                shim_entries = [entry for entry in entries
                                if entry["pid"] == bind["pid"] and entry["comm"] == "containerd-shim"]
                vm_prep = next((entry for entry in shim_entries
                                if "prepare vm socket config for sandbox." in entry["message"]), None)
                vm_start = next((entry for entry in shim_entries
                                 if entry["message"].strip() == "start vm"), None)
                agent_ready = next((entry for entry in shim_entries
                                    if "hybrid vsock: connected to HybridVsock" in entry["message"]), None)
                if vm_prep is None or vm_start is None or agent_ready is None:
                    raise RuntimeError(f"Missing runtime-rs milestones for {namespace}/{name}")
                tpl_restore = next((entry for entry in shim_entries
                                    if "Successfully restored VM from template" in entry["message"]), None)
                tpl_fallback = next((entry for entry in shim_entries
                                     if "no template vm found" in entry["message"]), None)
                rs_markers = {
                    "prepare vm socket config": vm_prep,
                    "start vm": vm_start,
                    "hybrid vsock connected": agent_ready,
                }
                if tpl_restore is not None:
                    rs_markers["restored VM from template"] = tpl_restore
                if tpl_fallback is not None:
                    rs_markers["no template vm found"] = tpl_fallback
                summary["shim_flavor"] = "kata-runtime-rs"
                summary["restored_from_template"] = tpl_restore is not None
                summary["hypervisor_ms"] = vm_start["time_ms"] - vm_prep["time_ms"]
                summary["guest_agent_ms"] = agent_ready["time_ms"] - vm_start["time_ms"]
                summary["markers"] = rs_markers
            if args.kata_template == "init" and not summary["restored_from_template"]:
                raise RuntimeError(f"Expected VM template restore for {namespace}/{name}, got normal boot")
            if args.kata_template == "off" and summary["restored_from_template"]:
                raise RuntimeError(f"Expected non-templated boot for {namespace}/{name}, got template restore")
        summaries.append(summary)
    denials = [entry for entry in entries if namespace in entry["message"]
               and "Error processing volume" in entry["message"]
               and "no relationship found" in entry["message"]]
    startup_denials = []
    after_start_denials = []
    for denial in denials:
        pod_name = re.search(r'pod="[^/]+/([^"]+)"', denial["message"])[1]
        pod = next(row for row in summaries if row["pod"] == pod_name)
        target = startup_denials if denial["time_ms"] < pod["sandbox_start_time_ms"] else after_start_denials
        target.append(denial)
    save(args.output / "native-summary.json", {
        "pods": summaries, "node_relationship_denials": denials,
        "startup_node_relationship_denials": startup_denials,
        "after_sandbox_start_relationship_denials": after_start_denials,
        "startup_node_relationship_denial_count": len(startup_denials),
        "all_volume_relationship_denial_count": len(denials)})


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    api = Kubernetes(args.context, args.output)
    namespace = "aks-repro-" + uuid.uuid4().hex[:10]
    since = utc()
    ns = None
    template_nodes = []
    try:
        if args.block_storage_class:
            storage = api.request("GET", "/apis/storage.k8s.io/v1/storageclasses/" + args.block_storage_class)
            save(args.output / "storageclass.json", storage)
            if (storage["provisioner"] != "disk.csi.azure.com"
                    or storage.get("volumeBindingMode") != "Immediate"
                    or storage.get("reclaimPolicy") != "Delete"):
                raise RuntimeError("Block trials require an Immediate/Delete Azure Disk CSI storage class")
        ns = api.request("POST", "/api/v1/namespaces", {
            "apiVersion": "v1", "kind": "Namespace",
            "metadata": {"name": namespace, "labels": {"aks-native-repro": namespace,
                                                       "pod-security.kubernetes.io/enforce": "privileged"}}})
        if args.scenario == "kata":
            template_nodes = configure_kata_template(api, args, namespace)
        save(args.output / "run.json", {
            "namespace": namespace, "context": args.context, "scenario": args.scenario,
            "pool": args.pool, "runtime_class": args.runtime_class, "image": IMAGE,
            "kata_template": args.kata_template,
            "block_storage_class": args.block_storage_class,
            "burst": args.burst,
            "started": since, "count": args.count, "rounds": args.rounds,
            "concurrency": args.concurrency,
            "planned_pods": args.rounds * args.concurrency if args.scenario == "kata" else args.count})
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
            if args.burst:
                results = run_burst(api, args, namespace)
            elif args.scenario == "kata":
                for round_number in range(args.rounds):
                    futures = [executor.submit(run_trial, api, args, namespace,
                                               round_number * args.concurrency + index,
                                               "first-wave" if round_number == 0 else f"later-{round_number}")
                               for index in range(args.concurrency)]
                    results.extend(future.result() for future in futures)
            else:
                results.extend(executor.map(
                    lambda index: run_trial(api, args, namespace, index, "volume"),
                    range(args.count)))
        save(args.output / "results.json", results)
    finally:
        try:
            if ns is not None:
                try:
                    if args.burst:
                        save(args.output / "pods-before-cleanup.json",
                             api.request("GET", f"/api/v1/namespaces/{namespace}/pods"))
                    collect(api, args, namespace, since)
                finally:
                    if template_nodes:
                        cleanup_kata_template(api, args, namespace, template_nodes)
                    if args.burst:
                        cleanup_burst(api, args, namespace)
                    remaining = api.request("GET", "/api/v1/persistentvolumes")
                    remaining["items"] = [
                        pv for pv in remaining["items"]
                        if pv["metadata"].get("labels", {}).get("aks-native-repro") == namespace
                        or (pv["spec"].get("claimRef") or {}).get("namespace") == namespace]
                    save(args.output / "remaining-pvs.json", remaining)
                    api.delete("/api/v1/namespaces", ns)
                    if remaining["items"]:
                        raise RuntimeError("Owned PVs remain; see remaining-pvs.json")
                    save(args.output / "cleanup.json", {
                        "namespace_deleted": namespace, "namespace_uid": ns["metadata"]["uid"],
                        "remaining_owned_pvs": 0})
        finally:
            api.close()
    journal_summary(args, namespace)
    print(json.dumps({"output": str(args.output), "completed": len(results),
                      "namespace_deleted": namespace}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scenario", choices=["kata", "volume"])
    parser.add_argument("--context", required=True)
    parser.add_argument("--pool", required=True)
    parser.add_argument("--runtime-class", default="")
    parser.add_argument("--kata-template", choices=["auto", "off", "init"], default="auto",
                        help="For kata-v2: keep host default (auto), force enable_template=false (off), or run kata-ctl factory init (init)")
    parser.add_argument("--block-storage-class", default="",
                        help="Use an existing Immediate/Delete Azure Disk CSI class for RWOP/Block trials")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--concurrency", type=int, default=4)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--count", type=int, default=200)
    parser.add_argument("--burst", action="store_true",
                        help="Prepare all Bound claims, barrier-release Pod creation, hold all Pods until capture")
    arguments = parser.parse_args()
    if not 1 <= arguments.concurrency <= 10 or not 1 <= arguments.count <= 1000 or not 2 <= arguments.rounds <= 5:
        parser.error("Require concurrency 1..10, count 1..1000 and rounds 2..5")
    if arguments.scenario == "kata" and not arguments.runtime_class:
        parser.error("Kata scenario requires an explicit --runtime-class")
    if arguments.scenario != "kata" and arguments.kata_template != "auto":
        parser.error("--kata-template is only supported by the kata scenario")
    if arguments.scenario != "volume" and arguments.block_storage_class:
        parser.error("--block-storage-class is only supported by the volume scenario")
    if arguments.burst and (arguments.scenario != "volume" or arguments.count > 100):
        parser.error("--burst requires volume scenario and count 1..100")
    if arguments.burst and (arguments.runtime_class or arguments.block_storage_class) and arguments.count > 4:
        parser.error("Kata/CSI bursts are limited to 4; use runc/hostPath for larger binding bursts")
    run(arguments)
