# AKS repro: transient kubelet PV/PVC NodeAuthorizer relationship denial

## Scope and status

This is a bounded, probabilistic standalone minimal reproduction using native
Kubernetes PV/PVC/Pod objects, built-in `hostPath` (with optional AKS-managed
Azure Disk CSI controls), and AKS's pre-cached MCR `pause` image
(`mcr.microsoft.com/oss/v2/kubernetes/pause:3.6`; earlier captured cohorts used
`registry.k8s.io/pause`). It does not install an application, extension, custom
controller, custom CSI driver, admission webhook or business logic.

**Reproduced standalone on November 13, 2026:** barrier-synchronized 100-Pod
bursts (`--burst --count 100`) using only stock native PV/PVC/Pod objects,
built-in `hostPath`, ordinary `runc` runtime, and `registry.k8s.io/pause`
reproduced **5 genuine startup NodeAuthorizer HTTP 403 denials** across
5 × 100-Pod cohorts (**4 PVC GET 403 + 1 PV GET 403**), including **3 startup
denials on the single-node `system` pool** without Kata or CSI drivers. Each
denial occurred after `pods/binding` succeeded (`201`), before the Pod's first
`RunPodSandbox`, and **29.9-38.5 seconds before any Pod `DELETE`**, triggering
an **11.4-16.2 second** kubelet Pod-sync retry stall. Rolling non-burst trials
(`concurrency <= 10`, 876 trials) produced **0** startup denials and 129
post-`DELETE` cleanup 403s, which must not be misclassified as startup races.

The target signature is a real kubelet identity, `system:node:<node>`, receiving
HTTP 403 on a PV/PVC GET because the node authorizer graph cannot find the
relationship, even though the claim is correctly bound and the Pod has been
assigned to that node. Do not emulate this using impersonation, missing RBAC,
an invalid claim UID, or a fake volume driver.

## Prerequisites and environment

- A Linux/WSL shell, Azure CLI, `kubectl`, Python 3.9 or later, and
  [native_repro.py](native_repro.py) in the same directory.
- A disposable AKS 1.37.1 cluster with operator permission to create native
  PVs/namespaces/Pods and use privileged native node-diagnostic Pods for journal collection.
- Full `kube-audit` diagnostic logging, not only `kube-audit-admin`, if exact
  kubelet GET responses are required. Enable `kube-apiserver` logs to identify
  the replica issuing a `NODE DENY`.

Validation target:

| Setting | Value |
|---|---|
| Tenant | `00000000-0000-4000-8000-000000000815` |
| Subscription | `00000000-0000-4000-8000-000000001074` |
| Resource group | `sanitized-resource-group-002` |
| Region | West US 2 |
| Cluster | `sanitized-cluster-001` |
| Network | Azure CNI Overlay, Azure dataplane, no Cilium |
| Kubernetes | `1.37.1` |
| Control-plane tier | Standard first; Free for matched-tier follow-up trials |

Provision an equivalent isolated single-pool cluster (Kata is **not** required
to reproduce this issue; ordinary `runc` Pods on the `system` pool suffice):

```bash
export SUBSCRIPTION=00000000-0000-4000-8000-000000001074
export RESOURCE_GROUP=sanitized-resource-group-002
export LOCATION=westus2
export AKS_NAME=sanitized-cluster-001
export REPRO_ROOT="$HOME/aks-native-repro"
mkdir -p "$REPRO_ROOT"

az group create --subscription "$SUBSCRIPTION" \
  --name "$RESOURCE_GROUP" --location "$LOCATION"
ssh-keygen -q -t rsa -b 3072 -N '' -f "$REPRO_ROOT/ssh-key"

az aks create --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" \
  --location "$LOCATION" --kubernetes-version 1.37.1 --tier free \
  --nodepool-name system --node-count 1 --node-vm-size Standard_D4s_v5 \
  --os-sku AzureLinux3 --node-osdisk-type Managed --node-osdisk-size 128 \
  --network-plugin azure --network-plugin-mode overlay --network-dataplane azure \
  --enable-managed-identity --ssh-key-value "$REPRO_ROOT/ssh-key.pub"

az aks get-credentials --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" --admin \
  --file "$REPRO_ROOT/kubeconfig" --context sanitized-context
export KUBECONFIG="$REPRO_ROOT/kubeconfig"
chmod 600 "$KUBECONFIG"
```

With the tested Azure CLI, `--admin --context sanitized-context` produces the
context name `sanitized-context-admin`. If reusing an existing disposable
cluster created on Standard tier, you can match the original Free tier before
starting a cohort (do not change a shared cluster's tier):

```bash
az aks update --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" --tier free --yes
az aks wait --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" --updated
```

For an equivalent scratch environment, enable diagnostics **before** the trials.
This creates billable Log Analytics storage with a 1-GB/day ingestion cap:

```bash
az monitor log-analytics workspace create --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --workspace-name logs-aks-native-repro \
  --location westus2 --retention-time 30 --quota 1
WORKSPACE_ID=$(az monitor log-analytics workspace show \
  --subscription "$SUBSCRIPTION" --resource-group "$RESOURCE_GROUP" \
  --workspace-name logs-aks-native-repro --query id -o tsv)
CLUSTER_ID=$(az aks show --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" --query id -o tsv)
az monitor diagnostic-settings create --subscription "$SUBSCRIPTION" \
  --name native-repro-audit --resource "$CLUSTER_ID" --workspace "$WORKSPACE_ID" \
  --export-to-resource-specific true \
  --logs '[{"category":"kube-audit","enabled":true},{"category":"kube-apiserver","enabled":true}]'
```

Verify ingestion and that the daily cap has not been reached. The node-journal
evidence remains local and does not depend on diagnostic ingestion.

## Minimal object sequence

Each iteration uses a new PVC, PV, Pod name and UID:

1. Create a PVC with `storageClassName: ""` and `ReadWriteOnce`.
2. Read its UID and create a static PV whose `claimRef` includes that exact
   namespace, name and UID.
3. Watch the PVC until it is `Bound`; verify `spec.volumeName`.
4. Immediately create a Pod referencing that PVC. Let the normal scheduler
   assign it; do not set `spec.nodeName` or bypass scheduling.
5. Observe readiness and retain Pod/PVC/PV identities and events.
6. Delete the Pod, then the PVC and PV, waiting for each deletion.

The PV uses this built-in volume source:

```yaml
spec:
  capacity:
    storage: 1Mi
  accessModes:
    - ReadWriteOnce
  storageClassName: ""
  persistentVolumeReclaimPolicy: Retain
  claimRef:
    namespace: <unique-namespace>
    name: <new-pvc>
    uid: <actual-pvc-uid>
  hostPath:
    path: /var/tmp/aks-pv-auth-repro
    type: DirectoryOrCreate
```

The Pod runs only `pause` and mounts the claim read-only at `/scratch`. There is
no application code or container-side storage operation. An empty scratch
directory may remain on the disposable node; no Azure disk is provisioned.

## Execute synchronized burst reproduction (recommended)

Rolling steady-state loops (`concurrency <= 10`, deleting each Pod immediately
after readiness) rarely overlap enough `pods/binding` events to expose the
authorizer lag, while immediate deletions generate cleanup-time 403 noise.
Use `--burst` to pre-bind all PV/PVC pairs first, release all 100 Pod creations
simultaneously behind a thread barrier, and **hold all 100 Pods alive** until
readiness observation and host-journal capture complete:

```bash
for run in a b c; do
  python3 native_repro.py volume \
    --context sanitized-context-admin --pool system \
    --burst --count 100 --concurrency 10 \
    --output "$REPRO_ROOT/burst-runc-system-100-$run"
done
```

Because this issue is probabilistic (~1% per Pod under a 100-Pod burst in our
validation: 5 startup denials across 500 burst Pods, with 2 of 5 cohorts
hitting 2-3 denials each), run 3-5 cohorts of 100 Pods on a node with default
`maxPods >= 110` (AKS Azure CNI Overlay defaults to 250). During the entire
observation window (`burst-release.json` -> `burst-observation.json`), zero Pod
deletions occur (`workload_deletion_during_observation: false`).

## Optional rolling steady-state and CSI raw-block controls

To compare against non-burst rolling load (where each worker deletes its Pod
before starting the next iteration):

```bash
python3 native_repro.py volume \
  --context sanitized-context-admin --pool system \
  --count 200 --concurrency 10 \
  --output "$REPRO_ROOT/pv-auth-runc"
```

There are no retries that replace a failed attempt with a successful one, no
artificial sleeps between binding and Pod publication, and no authorization
or runtime configuration changes. Kubernetes watches wait for actual object
transitions. The concurrency/count are bounded; the runner accepts at most
1,000 rolling trials (or 100 burst Pods) and 10 observation workers per run.

To check rolling load on already exercised Kata nodes:

```bash
python3 native_repro.py volume \
  --context sanitized-context-admin --pool kata --runtime-class kata-vm-isolation \
  --count 200 --concurrency 4 \
  --output "$REPRO_ROOT/pv-auth-kata"
```

If also testing optional Kata controls, add a `KataVmIsolation` user nodepool
and exercise it once beforehand so initial VM-boot latency does not confound
startup timing. Scheduling capacity may reduce the number of simultaneously
running Kata VMs on a single node; preserve actual Pod/node placement.

### Closer storage reduction: stock CSI, raw block, ReadWriteOncePod

The original incident used raw-block `ReadWriteOncePod` claims. To retain those
native semantics without installing the original custom driver, use the
cluster's standard `disk.csi.azure.com` driver and an Immediate-binding class:

```bash
kubectl --context sanitized-context-admin create -f - <<'YAML'
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: aks-repro-block-20261113
provisioner: disk.csi.azure.com
parameters:
  skuName: Standard_LRS
volumeBindingMode: Immediate
reclaimPolicy: Delete
YAML

python3 native_repro.py volume \
  --context sanitized-context-admin --pool system \
  --block-storage-class aks-repro-block-20261113 \
  --count 32 --concurrency 4 \
  --output "$REPRO_ROOT/pv-auth-block-rwop"
```

For the matched Kata variant, replace `--pool system` with
`--pool kata --runtime-class kata-vm-isolation` and use a new output directory.
Both variants were exercised in the validation below.

This provisions real, billable Azure managed disks. Check node attach limits
and use only a disposable cluster. Each trial requests 1 GiB, waits for `Bound`,
verifies the PV's exact claim UID and publishes a `pause` Pod with a
`volumeDevices` entry at `/dev/repro`. The process never reads or writes the
device. The driver, not the runner, provisions and deletes the disk.

The runner requires an existing Azure Disk CSI class with `Immediate` binding
and `Delete` reclaim. The usual `WaitForFirstConsumer` class is not equivalent
to this bound-before-Pod sequence. It waits for the reclaimed PV to disappear
after Pod/PVC deletion; it does not strip finalizers or force cloud deletion.
`storageclass.json` and the per-trial binding records retain the actual driver
and volume configuration. This preserves RWOP/block semantics but still does
not reproduce the original custom driver's implementation or API-server load.

## Required positive evidence

**Do not classify a long Pod startup alone as an authorization reproduction.**
Join all evidence using the exact Pod/PVC/PV names and UIDs:

- PVC `Bound` and correct PV `claimRef.uid` **before** Pod creation.
- Successful Pod binding to the rejecting kubelet's node.
- A real kubelet PV/PVC GET 403 containing `no relationship found`.
- The denial occurs during initial volume preparation, **before the first
  `RunPodSandbox` and before any Pod deletion**. Cleanup-time denials do not
  reproduce a startup authorization failure.
- Corresponding API-server `NODE DENY`, including server replica when available.
- Pod-sync failure, subsequent volume recovery and the actual delay.

The runner records binding snapshots, Pod snapshots, API timings/audit IDs,
events and raw host journals. `native-summary.json` separates pre-sandbox
startup denials from later denials. Use `startup_node_relationship_denial_count`,
not the raw count of error strings. An empty startup list means **not reproduced**
in this run, not success. Check exact DELETE audit timestamps as well: kubelet
can still process an old Pod after its authorization relationship was removed
by deletion, producing the same error text during cleanup.

Example Log Analytics queries after logs have ingested; substitute the run
namespace and exact UTC window from `run.json`:

```kusto
AKSAudit
| where TimeGenerated between (datetime(<start-utc>) .. datetime(<end-utc>))
| where tostring(ObjectRef.namespace) == "<run-namespace>"
    or tostring(ObjectRef.name) startswith "<run-namespace>-"
    or tostring(ObjectRef.name) in ("<captured-dynamic-pv-name>")
| project TimeGenerated, PodName, AuditId, Verb, User, ObjectRef,
          ResponseStatus, RequestReceivedTime, StageReceivedTime
| order by RequestReceivedTime asc
```

```kusto
AKSControlPlane
| where TimeGenerated between (datetime(<start-utc>) .. datetime(<end-utc>))
| where Category == "kube-apiserver"
| where Message contains "<run-namespace>"
| where Message contains "NODE DENY"
| project TimeGenerated, PodName, Message
| order by TimeGenerated asc
```

Audit records for cluster-scoped PVs have no namespace: retain the exact PV
name filter, not only the namespace filter. Dynamically provisioned names such
as `pvc-<uid>` do not share the run namespace prefix: use `spec.volumeName`
from every captured binding record. Check the relevant LAW table and
ingestion coverage rather than interpreting missing GET records as success.

## Original incident: native Kubernetes evidence, not a new reproduction

One original startup failure on November 13, 2026 had this sequence:

| UTC | Native event |
|---|---|
| `07:49:15.556927` | PVC was Bound to the correct PV and claim UID |
| `07:49:16.032098` | Pod created referencing that PVC |
| `07:49:16.178640` | Scheduler Pod binding completed |
| `07:49:16.235968` | The binding replica reported an unknown-Pod authorization lookup |
| `07:49:16.240297` | Same replica emitted the PV `NODE DENY` |
| `07:49:16.241173` | Kubelet logged the real PV GET 403 / volume-processing failure |
| `07:49:16.483037` | Kubelet logged Pod-sync failure |
| `07:49:32.522233` | First Pod DELETE request, more than 16 seconds after denial |

The node was `sanitized-node-003`; the denying API server was
`sanitized-apiserver-016`. The claim UID was
`00000000-0000-4000-8000-0000000004d3`. The denial was approximately **61.7 ms
after completed binding**, before volume/VM startup, not a cleanup denial.
The Pod UID was `00000000-0000-4000-8000-000000000a4e`; binding audit ID was
`00000000-0000-4000-8000-000000000b5d`. Retained DELETE audit records were
checked for all five original cases: none preceded its startup denial.

Across five linked original cases, four denied PV GET and one denied PVC GET;
all five server-side denials came from that replica. Three occurred after the
nodes had already been exercised. This is not equivalent to a new node's
certificate or node identity being unrecognized.

Original write/binding audit records and node/server logs were retained.
**Full historical GET audit records were not retained**; the actual 403 comes
from the kubelet's recorded server response, correlated with the server-side
denial. New validation enables full audit to close this evidence gap.
This historical sequence is kept strictly separate from the standalone
reproduction results below.

## Verified standalone results

### 1. Positive reproduction: barrier-synchronized native bursts (`runc` + `hostPath` + `pause`)

On the isolated Free-tier AKS 1.37.1 cluster (`sanitized-cluster-001`, two
`kube-apiserver` replicas `sanitized-apiserver-014` and
`sanitized-apiserver-013`), we ran one 10-Pod smoke burst and five
100-Pod bursts (`client_submit_spread_ms` 62.4-88.4 ms). All Pods were held
alive with zero deletions until all 100 reached Ready and host journals were
captured:

| Cohort | Node pool / runtime | Tier | Burst Pods | Startup volume 403s | Post-start / cleanup 403s during observation |
|---|---|---|---:|---:|---:|
| `runc-system-10` | `system` / `runc` | Free | 10 | 0 | 0 |
| `runc-system-100-a` | `system` / `runc` | Free | 100 | 0 | 0 |
| `runc-system-100-b` | `system` / `runc` | Free | 100 | 0 | 0 |
| `runc-katahost-100` | `kata` (`D8s_v5`) / `runc` (no Kata VM) | Free | 100 | **2** (2 PVC) | 0 |
| `runc-system-100-c` | `system` (`D4s_v5`) / `runc` | Free | 100 | **3** (2 PVC, 1 PV) | 0 |
| `runc-katahost-100-b` | `kata` (`D8s_v5`) / `runc` (no Kata VM) | Free | 100 | 0 | 0 |

All **5 startup volume 403s** are independently confirmed across kubelet host
journals (`desired_state_of_world_populator.go:302` -> `pod_workers.go:1338`),
`AKSAudit` (`ResponseStatus.code == 403`), and `AKSControlPlane`
(`"NODE DENY"`):

| Cohort / Pod | Pod UID / PVC UID | Binding `201` (replica, UTC, AuditId) | Denied GET `403` (replica, UTC, resource, AuditId) | Bind -> 403 | Retry `200` backoff | First Pod `DELETE` |
|---|---|---|---|---:|---:|---:|
| `runc-system-100-c` / `p-0004` | `00000000-0000-4000-8000-000000000494` / `00000000-0000-4000-8000-0000000007c0` | `sanitized-apiserver-014` `14:41:46.916759Z` (`00000000-0000-4000-8000-000000000bf4`) | **`sanitized-apiserver-014` (same replica)** `14:41:46.934466Z` PVC (`00000000-0000-4000-8000-000000000de4`) | **+17.7 ms** | 12.85 s | +31.81 s |
| `runc-system-100-c` / `p-0039` | `00000000-0000-4000-8000-0000000006a0` / `00000000-0000-4000-8000-00000000019b` | `sanitized-apiserver-013` `14:41:46.752393Z` (`00000000-0000-4000-8000-000000000253`) | `sanitized-apiserver-014` `14:41:46.813966Z` PVC (`00000000-0000-4000-8000-0000000006b3`) | **+61.6 ms** | 12.05 s | +32.26 s |
| `runc-system-100-c` / `p-0051` | `00000000-0000-4000-8000-000000000c07` / `00000000-0000-4000-8000-000000000df3` | `sanitized-apiserver-014` `14:41:48.365701Z` (`00000000-0000-4000-8000-00000000043a`) | `sanitized-apiserver-013` `14:41:49.367216Z` **PV** (`00000000-0000-4000-8000-00000000043e`) | **+1,001.5 ms** | 11.43 s | +29.90 s |
| `runc-katahost-100` / `p-0088` | `00000000-0000-4000-8000-000000001118` / `00000000-0000-4000-8000-000000000e12` | `sanitized-apiserver-014` `13:35:43.517214Z` (`00000000-0000-4000-8000-000000000832`) | `sanitized-apiserver-013` `13:35:43.632895Z` PVC (`00000000-0000-4000-8000-000000000a63`) | **+115.7 ms** | 16.20 s | +38.52 s |
| `runc-katahost-100` / `p-0020` | `00000000-0000-4000-8000-00000000042a` / `00000000-0000-4000-8000-000000000c0d` | `sanitized-apiserver-014` `13:35:43.212964Z` (`00000000-0000-4000-8000-0000000002b2`) | `sanitized-apiserver-013` `13:35:43.448370Z` PVC (`00000000-0000-4000-8000-00000000054f`) | **+235.4 ms** | 12.92 s | +37.63 s |

Three concrete findings emerge directly from these standalone audit traces:

1. **Same-replica informer/graph race (`p-0004`):** `pods/binding` completed on
   `sanitized-apiserver-014` at `14:41:46.916759Z`, kubelet received the Pod watch event at
   `14:41:46.874-14:41:46.880Z`, and kubelet's `GET persistentvolumeclaims/p-0004`
   arrived at **that same replica `sanitized-apiserver-014`** 17.7 ms after binding completion
   (`14:41:46.934466Z`), where `sanitized-apiserver-014` emitted `NODE DENY` and returned `403`.
   Completing `pods/binding` and delivering watch events does not guarantee
   `NodeAuthorizer`'s internal Pod informer (`graph_populator.go`) has added
   the `Node -> Pod -> PVC -> PV` edges yet.
2. **Cross-replica lag exceeding 1.0 second (`p-0051`):** `pods/binding`
   completed on `sanitized-apiserver-014` at `14:41:48.365701Z`. At `14:41:49.358269Z` (+992.6 ms),
   kubelet's `GET persistentvolumeclaims/p-0051` hit `sanitized-apiserver-014` and **succeeded
   with HTTP 200** (`00000000-0000-4000-8000-000000000007`). Just 9 ms later
   (`14:41:49.367216Z`, **+1,001.5 ms after binding**), kubelet's follow-up
   `GET persistentvolumes/sanitized-namespace-009-p-0051` landed on `sanitized-apiserver-013`, which
   still lacked the relationship in its `NodeAuthorizer` graph and returned
   HTTP 403 (`NODE DENY`). This explains why either `PVC` or `PV` GET can fail.
3. **Kubelet Pod-sync backoff amplification:** Every transient 403 aborted
   initial volume setup (`Unable to attach or mount volumes for pod; skipping pod`
   / `Error syncing pod, skipping`), stalling volume mount and `RunPodSandbox`
   for **11.43-16.20 seconds** (`podStartE2EDuration` 16.75-26.33 s with
   `totalImagesPullingTime="0s"`).

Note: synchronized bursts were validated on the matched Free-tier control plane;
Standard-tier synchronized bursts were not separately tested.

### 2. Negative control: rolling non-burst cohorts and cleanup-noise exclusion

Before testing synchronized bursts, 876 rolling non-burst trials (`concurrency <= 10`,
immediately deleting each Pod after Ready) were run across Standard and Free
tiers, `runc` and Kata runtimes, and `hostPath` plus 68 real Azure Disk CSI
raw-block/`ReadWriteOncePod` claims:

| Runtime / node pool | Tier | Rolling trials | Startup volume denials | Post-`DELETE` volume-error journal entries |
|---|---|---:|---:|---:|
| runc / system | Standard | 200 | 0 | 22 |
| runc / previously exercised Kata node | Standard | 200 | 0 | 33 |
| Kata / Kata node, smoke | Standard | 4 | 0 | 0 |
| Kata / previously exercised Kata node | Free | 200 | 0 | 30 |
| Kata / Kata node, final-collector smoke | Free | 4 | 0 | 1 |
| runc / system | Free | 200 | 0 | 34 |
| runc / system, CSI RWOP/block smoke | Free | 2 | 0 | 0 |
| runc / system, CSI RWOP/block | Free | 32 | 0 | 4 |
| Kata / Kata node, CSI RWOP/block smoke | Free | 2 | 0 | 0 |
| Kata / Kata node, CSI RWOP/block | Free | 32 | 0 | 5 |

Full audit joined **all 876 rolling workload `DELETE`s** and **all 129 rolling
PV/PVC GET 403s**: 100% of those 129 rolling GET 403s began **after** the
corresponding Pod `DELETE` request and after `RunPodSandbox` (for example,
volume mounted at `10:39:01.907Z`, Ready at `10:39:03.694Z`, Pod `DELETE` at
`10:39:03.733Z`, PV GET 403 at `10:39:03.738Z`). Holding Pods alive in
`--burst` mode eliminates this cleanup noise while isolating the true startup
authorizer race.

The 200-trial rolling Kata capture initially returned only the tail of a large
diagnostic Pod's stdout log. All measured Pod records and cleanup were preserved;
original host journals were recovered in a capture-only pass without rerunning
Pods, and the supplied collector now copies a completed compressed file using
`kubectl exec`.

## Interpretation and AKS investigation request

Node authentication and object authorization are different. The relationship
needed for a newly assigned Pod is conceptually:

```text
requested PV -> PVC -> assigned Pod -> requesting Node
```

Successful object writes do not prove every authorizer informer has processed
them. A rejection even on the server that accepted the binding is relevant:
write completion is not an informer/graph barrier.

Please investigate the rejecting API-server's Pod/PV informer visibility and
NodeAuthorizer graph event ordering. Also investigate whether kubelet's
volume-processing error path amplifies a short denial into its ordinary
Pod-sync retry delay. Upstream v1.37.1 has a default 10-second error backoff
with 0.5 jitter; the observed recovery interval is **not** a measurement of
how long authorization remained continuously broken.

Do not resolve this by granting nodes broad PV/PVC access or inserting an
arbitrary sleep before Pod creation. Identify the stale relationship and
the actual retry behavior first.

## Cleanup and evidence

The runner deletes its uniquely owned Pods, PVCs, PVs and namespace using UID
preconditions where it issues deletes itself. CSI disks/PVs use the driver's
normal Delete reclaim path. It captures journals before removing its diagnostic namespace.
`cleanup.json` and `remaining-pvs.json` record cleanup. Files and logs remain
local; no tokens or kubeconfig are included in a report attachment.

The standalone package `aks-pv-pvc-node-authorizer.zip` includes this document,
[native_repro.py](native_repro.py), `evidence/validation.json`,
`evidence/burst-20261113T1326/burst-qualification.json`, per-run native
summaries and source excerpts, exact claim/Pod snapshots, qualified rolling
GET/DELETE audit evidence, and `evidence/original-startup-cases.json`.
The historical and standalone-run evidence are explicitly separate; full
unreviewed host journals, kubeconfig and SSH keys are not attached.

After all block trials and PV reclamation have completed, remove only the
scratch storage class you created:

```bash
kubectl --context sanitized-context-admin delete storageclass aks-repro-block-20261113
```

The disposable AKS cluster can then be stopped after validation:

```bash
az aks stop --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME"
az aks show --subscription "$SUBSCRIPTION" \
  --resource-group "$RESOURCE_GROUP" --name "$AKS_NAME" --query powerState.code
```

Stopping does not delete managed OS disks or the Log Analytics workspace.
Never delete unrelated resources or the entire shared resource group.

## References

- [Kubernetes Node authorization](https://kubernetes.io/docs/reference/access-authn-authz/node/)
- [NodeAuthorizer graph population](https://github.com/kubernetes/kubernetes/blob/v1.37.1/plugin/pkg/auth/authorizer/node/graph_populator.go)
- [Kubelet volume manager](https://github.com/kubernetes/kubernetes/blob/v1.37.1/pkg/kubelet/volumemanager/volume_manager.go)
- [Kubelet Pod worker retries](https://github.com/kubernetes/kubernetes/blob/v1.37.1/pkg/kubelet/pod_workers.go)
- [AKS Azure Disk CSI provisioning](https://learn.microsoft.com/azure/aks/create-volume-azure-disk)
- [Kubernetes persistent volume modes and access modes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)
